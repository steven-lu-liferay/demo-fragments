queryStrucContentData(fragmentElement, 1);
